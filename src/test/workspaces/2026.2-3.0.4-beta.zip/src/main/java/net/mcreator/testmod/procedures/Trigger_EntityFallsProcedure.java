package net.mcreator.testmod.procedures;

public class Trigger_EntityFallsProcedure {
	/* [mixin:entity_falls] */
	public static void execute() {
	}
}