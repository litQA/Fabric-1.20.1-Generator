package net.mcreator.testmod.procedures;

public class Trigger_FarmlandTrampledProcedure {
	/* [mixin:farmland_trampled] */
	public static void execute() {
	}
}