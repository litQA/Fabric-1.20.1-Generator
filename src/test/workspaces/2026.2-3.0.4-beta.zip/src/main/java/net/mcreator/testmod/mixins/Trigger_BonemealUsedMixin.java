package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

@Mixin(BoneMealItem.class)
abstract class Trigger_BonemealUsedMixin {
	@Inject(method = "useOn(Lnet/minecraft/world/item/context/UseOnContext;)Lnet/minecraft/world/InteractionResult;", at = @At("HEAD"), cancellable = true, require = 0)
	private void onBonemealUsed(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
		if (!(context.getLevel() instanceof ServerLevel level))
			return;
		Player player = context.getPlayer();
		if (player == null)
			return;
		BlockPos pos = context.getClickedPos();
		BlockState state = level.getBlockState(pos);
		boolean farmLand = state.is(net.minecraft.world.level.block.Blocks.FARMLAND);
		if (!farmLand && !(state.getBlock() instanceof BonemealableBlock bonemealable && bonemealable.isValidBonemealTarget(level, pos, state, false)))
			return;
		System.out.println("[MixinProbe] bonemeal_used reached");
		net.mcreator.testmod.procedures.Trigger_BonemealUsedProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			cir.setReturnValue(InteractionResult.FAIL);
	}
}