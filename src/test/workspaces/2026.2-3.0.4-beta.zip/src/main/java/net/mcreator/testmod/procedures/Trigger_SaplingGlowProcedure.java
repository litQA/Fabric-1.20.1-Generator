package net.mcreator.testmod.procedures;

public class Trigger_SaplingGlowProcedure {
	/* [mixin:sapling_glow] */
	public static void execute() {
	}
}