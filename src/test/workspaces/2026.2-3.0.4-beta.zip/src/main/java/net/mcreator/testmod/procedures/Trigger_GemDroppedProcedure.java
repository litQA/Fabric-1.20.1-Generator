package net.mcreator.testmod.procedures;

public class Trigger_GemDroppedProcedure {
	/* [mixin:gem_dropped] */
	public static void execute() {
	}
}