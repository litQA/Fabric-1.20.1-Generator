package net.mcreator.testmod.procedures;

public class Trigger_EntityBlocksProcedure {
	/* [mixin:entity_blocks] */
	public static void execute() {
	}
}