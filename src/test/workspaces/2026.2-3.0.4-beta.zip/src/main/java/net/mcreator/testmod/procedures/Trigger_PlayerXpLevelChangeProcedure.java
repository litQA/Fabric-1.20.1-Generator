package net.mcreator.testmod.procedures;

public class Trigger_PlayerXpLevelChangeProcedure {
	/* [mixin:player_xp_level_change] */
	public static void execute() {
	}
}