package net.mcreator.testmod.procedures;

public class Trigger_CropAttemptsGrowthProcedure {
	/* [mixin:crop_attempts_growth] */
	public static void execute() {
	}
}