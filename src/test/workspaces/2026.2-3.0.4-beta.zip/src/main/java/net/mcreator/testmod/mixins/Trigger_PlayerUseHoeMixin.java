package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.BlockPos;

@Mixin(HoeItem.class)
abstract class Trigger_PlayerUseHoeMixin {
	@Inject(method = "useOn(Lnet/minecraft/world/item/context/UseOnContext;)Lnet/minecraft/world/InteractionResult;", at = @At("RETURN"), cancellable = true, require = 0)
	private void onUseHoe(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
		if (!cir.getReturnValue().consumesAction() || context.getPlayer() == null)
			return;
		BlockPos pos = context.getClickedPos();
		System.out.println("[MixinProbe] player_use_hoe reached");
		net.mcreator.testmod.procedures.Trigger_PlayerUseHoeProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			cir.setReturnValue(InteractionResult.FAIL);
	}
}