package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;

@Mixin(LivingEntity.class)
abstract class Trigger_EntityBlocksMixin {
	@Inject(method = "hurt(Lnet/minecraft/world/damagesource/DamageSource;F)Z", at = @At("HEAD"), cancellable = true, require = 0)
	private void onHurtBlocked(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (self.level().isClientSide() || !self.isDamageSourceBlocked(source))
			return;
		if (self instanceof ServerPlayer serverPlayer && serverPlayer.hasDisconnected())
			return;
		System.out.println("[MixinProbe] entity_blocks reached");
		net.mcreator.testmod.procedures.Trigger_EntityBlocksProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			cir.setReturnValue(false);
	}
}