package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LivingEntity;

@Mixin(LivingEntity.class)
abstract class Trigger_EntityHealedMixin {
	@Inject(method = "heal(F)V", at = @At("HEAD"), cancellable = true, require = 0)
	private void onEntityHealed(float amount, CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		System.out.println("[MixinProbe] entity_healed reached");
		net.mcreator.testmod.procedures.Trigger_EntityHealedProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			ci.cancel();
	}
}