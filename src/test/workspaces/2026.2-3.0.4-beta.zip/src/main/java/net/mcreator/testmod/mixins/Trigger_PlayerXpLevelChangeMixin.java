package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.player.Player;

@Mixin(Player.class)
abstract class Trigger_PlayerXpLevelChangeMixin {
	@Inject(method = "giveExperienceLevels(I)V", at = @At("HEAD"), require = 0)
	private void onXpLevelChange(int amount, CallbackInfo ci) {
		Player self = (Player) (Object) this;
		System.out.println("[MixinProbe] player_xp_level_change reached");
		net.mcreator.testmod.procedures.Trigger_PlayerXpLevelChangeProcedure.execute();
	}
}