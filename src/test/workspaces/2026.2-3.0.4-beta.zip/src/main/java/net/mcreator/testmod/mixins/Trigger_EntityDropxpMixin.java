package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LivingEntity;

@Mixin(LivingEntity.class)
abstract class Trigger_EntityDropxpMixin {
	@Inject(method = "dropExperience()V", at = @At("TAIL"), require = 0)
	private void onDropExperience(CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		System.out.println("[MixinProbe] entity_dropxp reached");
		net.mcreator.testmod.procedures.Trigger_EntityDropxpProcedure.execute();
	}
}