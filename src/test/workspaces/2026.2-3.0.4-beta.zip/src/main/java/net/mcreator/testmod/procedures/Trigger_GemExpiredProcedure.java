package net.mcreator.testmod.procedures;

public class Trigger_GemExpiredProcedure {
	/* [mixin:gem_expired] */
	public static void execute() {
	}
}