package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;

@Mixin(LivingEntity.class)
abstract class Trigger_EntityItemPickupMixin {
	@Inject(method = "onItemPickup(Lnet/minecraft/world/entity/item/ItemEntity;)V", at = @At("HEAD"), require = 0)
	private void onItemPickup(ItemEntity itemEntity, CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		System.out.println("[MixinProbe] entity_item_pickup reached");
		net.mcreator.testmod.procedures.Trigger_EntityItemPickupProcedure.execute();
	}
}