package net.mcreator.testmod.procedures;

public class Trigger_ItemCraftedProcedure {
	/* [mixin:item_crafted] */
	public static void execute() {
	}
}