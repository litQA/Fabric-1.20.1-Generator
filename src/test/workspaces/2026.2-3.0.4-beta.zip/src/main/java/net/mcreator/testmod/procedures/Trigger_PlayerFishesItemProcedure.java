package net.mcreator.testmod.procedures;

public class Trigger_PlayerFishesItemProcedure {
	/* [mixin:player_fishes_item] */
	public static void execute() {
	}
}