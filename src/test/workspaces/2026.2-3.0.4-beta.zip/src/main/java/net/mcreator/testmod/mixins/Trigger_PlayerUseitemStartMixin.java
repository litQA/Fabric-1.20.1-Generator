package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;

@Mixin(LivingEntity.class)
abstract class Trigger_PlayerUseitemStartMixin {
	@Inject(method = "startUsingItem(Lnet/minecraft/world/InteractionHand;)V", at = @At("HEAD"), cancellable = true, require = 0)
	private void onStartUsingItem(InteractionHand hand, CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (self.level().isClientSide() || self.isUsingItem())
			return;
		if (self instanceof ServerPlayer serverPlayer && (serverPlayer.connection == null || serverPlayer.hasDisconnected()))
			return;
		System.out.println("[MixinProbe] player_useitem_start reached");
		net.mcreator.testmod.procedures.Trigger_PlayerUseitemStartProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			ci.cancel();
	}
}