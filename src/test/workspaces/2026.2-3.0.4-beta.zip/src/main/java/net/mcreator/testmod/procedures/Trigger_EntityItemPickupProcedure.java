package net.mcreator.testmod.procedures;

public class Trigger_EntityItemPickupProcedure {
	/* [mixin:entity_item_pickup] */
	public static void execute() {
	}
}