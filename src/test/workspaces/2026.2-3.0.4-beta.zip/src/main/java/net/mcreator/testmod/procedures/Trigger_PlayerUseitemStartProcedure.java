package net.mcreator.testmod.procedures;

public class Trigger_PlayerUseitemStartProcedure {
	/* [mixin:player_useitem_start] */
	public static void execute() {
	}
}