package net.mcreator.testmod.procedures;

public class Trigger_EntityPickupxpProcedure {
	/* [mixin:entity_pickupxp] */
	public static void execute() {
	}
}