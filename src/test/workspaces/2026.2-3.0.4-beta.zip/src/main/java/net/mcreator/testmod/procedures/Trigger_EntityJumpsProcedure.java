package net.mcreator.testmod.procedures;

public class Trigger_EntityJumpsProcedure {
	/* [mixin:entity_jumps] */
	public static void execute() {
	}
}