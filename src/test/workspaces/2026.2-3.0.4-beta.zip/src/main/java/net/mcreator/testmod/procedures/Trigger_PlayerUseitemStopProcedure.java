package net.mcreator.testmod.procedures;

public class Trigger_PlayerUseitemStopProcedure {
	/* [mixin:player_useitem_stop] */
	public static void execute() {
	}
}