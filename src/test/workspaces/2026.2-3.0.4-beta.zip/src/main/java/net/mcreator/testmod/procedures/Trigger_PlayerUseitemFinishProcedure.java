package net.mcreator.testmod.procedures;

public class Trigger_PlayerUseitemFinishProcedure {
	/* [mixin:player_useitem_finish] */
	public static void execute() {
	}
}