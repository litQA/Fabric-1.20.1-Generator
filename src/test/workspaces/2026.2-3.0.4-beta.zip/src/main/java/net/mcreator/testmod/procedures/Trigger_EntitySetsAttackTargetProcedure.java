package net.mcreator.testmod.procedures;

public class Trigger_EntitySetsAttackTargetProcedure {
	/* [mixin:entity_sets_attack_target] */
	public static void execute() {
	}
}