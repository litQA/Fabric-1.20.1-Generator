package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;

@Mixin(LivingEntity.class)
abstract class Trigger_EntityUsesTotemMixin {
	@Inject(method = "checkTotemDeathProtection(Lnet/minecraft/world/damagesource/DamageSource;)Z", at = @At("HEAD"), cancellable = true, require = 0)
	private void onCheckTotem(DamageSource source, CallbackInfoReturnable<Boolean> cir) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (self.level().isClientSide())
			return;
		System.out.println("[MixinProbe] entity_uses_totem reached");
		net.mcreator.testmod.procedures.Trigger_EntityUsesTotemProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			cir.setReturnValue(false);
	}
}