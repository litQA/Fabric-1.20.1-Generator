package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.advancements.Advancement;

@Mixin(PlayerAdvancements.class)
abstract class Trigger_PlayerCompletesAdvancementMixin {
	@Shadow
	private ServerPlayer player;

	@Inject(method = "award(Lnet/minecraft/advancements/Advancement;Ljava/lang/String;)Z", at = @At("RETURN"), require = 0)
	private void onAward(Advancement advancement, String criterion, CallbackInfoReturnable<Boolean> cir) {
		if (!Boolean.TRUE.equals(cir.getReturnValue()))
			return;
		if (player.connection == null || player.hasDisconnected())
			return;
		System.out.println("[MixinProbe] player_completes_advancement reached");
		net.mcreator.testmod.procedures.Trigger_PlayerCompletesAdvancementProcedure.execute();
	}
}