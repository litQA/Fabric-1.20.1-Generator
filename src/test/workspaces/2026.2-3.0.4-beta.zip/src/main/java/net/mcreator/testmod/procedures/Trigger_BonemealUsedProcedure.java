package net.mcreator.testmod.procedures;

public class Trigger_BonemealUsedProcedure {
	/* [mixin:bonemeal_used] */
	public static void execute() {
	}
}