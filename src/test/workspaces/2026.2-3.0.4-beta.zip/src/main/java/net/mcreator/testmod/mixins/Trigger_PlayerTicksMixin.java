package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.player.Player;

@Mixin(Player.class)
abstract class Trigger_PlayerTicksMixin {
	@Inject(method = "tick()V", at = @At("TAIL"), require = 0)
	private void onPlayerTick(CallbackInfo ci) {
		Player self = (Player) (Object) this;
		System.out.println("[MixinProbe] player_ticks reached");
		net.mcreator.testmod.procedures.Trigger_PlayerTicksProcedure.execute();
	}
}