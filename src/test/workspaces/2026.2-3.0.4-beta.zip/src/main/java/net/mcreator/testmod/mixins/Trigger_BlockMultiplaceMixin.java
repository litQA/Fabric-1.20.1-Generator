package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.BlockPos;

@Mixin(ItemStack.class)
abstract class Trigger_BlockMultiplaceMixin {
	@Inject(method = "useOn(Lnet/minecraft/world/item/context/UseOnContext;)Lnet/minecraft/world/InteractionResult;", at = @At("TAIL"), cancellable = true, require = 0)
	private void onMultiplace(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
		Player player = context.getPlayer();
		if (player == null || context.getLevel().isClientSide())
			return;
		BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
		BlockPos against = context.getClickedPos();
		System.out.println("[MixinProbe] block_multiplace reached");
		net.mcreator.testmod.procedures.Trigger_BlockMultiplaceProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			cir.setReturnValue(InteractionResult.FAIL);
	}
}