package net.mcreator.testmod.procedures;

public class Trigger_CommandExecutedProcedure {
	/* [mixin:command_executed] */
	public static void execute() {
	}
}