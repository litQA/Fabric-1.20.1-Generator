package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;

@Mixin(Mob.class)
abstract class Trigger_EntitySetsAttackTargetMixin {
	@Inject(method = "setTarget(Lnet/minecraft/world/entity/LivingEntity;)V", at = @At("HEAD"), require = 0)
	private void onSetTarget(LivingEntity target, CallbackInfo ci) {
		Mob self = (Mob) (Object) this;
		if (self.level().isClientSide())
			return;
		System.out.println("[MixinProbe] entity_sets_attack_target reached");
		net.mcreator.testmod.procedures.Trigger_EntitySetsAttackTargetProcedure.execute();
	}
}