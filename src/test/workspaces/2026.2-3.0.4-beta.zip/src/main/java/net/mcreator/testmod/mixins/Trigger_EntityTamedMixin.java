package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;

@Mixin(TamableAnimal.class)
abstract class Trigger_EntityTamedMixin {
	@Inject(method = "tame(Lnet/minecraft/world/entity/player/Player;)V", at = @At("TAIL"), require = 0)
	private void onTamed(Player player, CallbackInfo ci) {
		TamableAnimal self = (TamableAnimal) (Object) this;
		System.out.println("[MixinProbe] entity_tamed reached");
		net.mcreator.testmod.procedures.Trigger_EntityTamedProcedure.execute();
	}
}