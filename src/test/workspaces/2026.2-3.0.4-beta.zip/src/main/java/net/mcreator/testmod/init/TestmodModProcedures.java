/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.testmod.init;

import net.mcreator.testmod.procedures.*;

@SuppressWarnings("InstantiationOfUtilityClass")
public class TestmodModProcedures {
	public static void load() {
		new Trigger_BlockMultiplaceProcedure();
		new Trigger_BonemealUsedProcedure();
		new Trigger_CommandExecutedProcedure();
		new Trigger_CropAttemptsGrowthProcedure();
		new Trigger_EntityBlocksProcedure();
		new Trigger_EntityDropxpProcedure();
		new Trigger_EntityFallsProcedure();
		new Trigger_EntityHealedProcedure();
		new Trigger_EntityItemPickupProcedure();
		new Trigger_EntityJumpsProcedure();
		new Trigger_EntityPickupxpProcedure();
		new Trigger_EntitySetsAttackTargetProcedure();
		new Trigger_EntityStruckByLightningProcedure();
		new Trigger_EntityTamedProcedure();
		new Trigger_EntityUsesTotemProcedure();
		new Trigger_FarmlandTrampledProcedure();
		new Trigger_GemDroppedProcedure();
		new Trigger_GemExpiredProcedure();
		new Trigger_ItemCraftedProcedure();
		new Trigger_PlayerCompletesAdvancementProcedure();
		new Trigger_PlayerFishesItemProcedure();
		new Trigger_PlayerTicksProcedure();
		new Trigger_PlayerTicksXYZProcedure();
		new Trigger_PlayerUseHoeProcedure();
		new Trigger_PlayerUseitemFinishProcedure();
		new Trigger_PlayerUseitemStartProcedure();
		new Trigger_PlayerUseitemStopProcedure();
		new Trigger_PlayerXpChangeProcedure();
		new Trigger_PlayerXpLevelChangeProcedure();
		new Trigger_SaplingGlowProcedure();
	}
}