package net.mcreator.testmod.procedures;

public class Trigger_EntityUsesTotemProcedure {
	/* [mixin:entity_uses_totem] */
	public static void execute() {
	}
}