package net.mcreator.testmod.procedures;

public class Trigger_EntityTamedProcedure {
	/* [mixin:entity_tamed] */
	public static void execute() {
	}
}