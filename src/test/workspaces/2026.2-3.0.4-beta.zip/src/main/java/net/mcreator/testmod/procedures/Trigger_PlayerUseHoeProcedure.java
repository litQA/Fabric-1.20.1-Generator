package net.mcreator.testmod.procedures;

public class Trigger_PlayerUseHoeProcedure {
	/* [mixin:player_use_hoe] */
	public static void execute() {
	}
}