package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.item.ItemEntity;

@Mixin(ItemEntity.class)
abstract class Trigger_GemExpiredMixin {
	@Inject(method = "tick()V", at = @At("HEAD"), require = 0)
	private void onItemTick(CallbackInfo ci) {
		ItemEntity self = (ItemEntity) (Object) this;
		if (self.level().isClientSide() || self.getAge() != 5999)
			return;
		System.out.println("[MixinProbe] gem_expired reached");
		net.mcreator.testmod.procedures.Trigger_GemExpiredProcedure.execute();
	}
}