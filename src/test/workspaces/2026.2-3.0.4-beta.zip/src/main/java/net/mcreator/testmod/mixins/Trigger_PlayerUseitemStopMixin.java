package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerPlayer;

@Mixin(LivingEntity.class)
abstract class Trigger_PlayerUseitemStopMixin {
	@Inject(method = "releaseUsingItem()V", at = @At("HEAD"), cancellable = true, require = 0)
	private void onReleaseUsingItem(CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (self.level().isClientSide() || self.getUseItem().isEmpty())
			return;
		if (self instanceof ServerPlayer serverPlayer && (serverPlayer.connection == null || serverPlayer.hasDisconnected()))
			return;
		System.out.println("[MixinProbe] player_useitem_stop reached");
		net.mcreator.testmod.procedures.Trigger_PlayerUseitemStopProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			ci.cancel();
	}
}