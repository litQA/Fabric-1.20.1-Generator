package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.player.Player;

@Mixin(FishingHook.class)
abstract class Trigger_PlayerFishesItemMixin {
	@Inject(method = "retrieve(Lnet/minecraft/world/item/ItemStack;)I", at = @At("HEAD"), require = 0)
	private void onRetrieve(ItemStack caught, CallbackInfoReturnable<Integer> cir) {
		if (caught.isEmpty())
			return;
		Player player = ((FishingHook) (Object) this).getPlayerOwner();
		if (player == null || player.level().isClientSide())
			return;
		System.out.println("[MixinProbe] player_fishes_item reached");
		net.mcreator.testmod.procedures.Trigger_PlayerFishesItemProcedure.execute();
	}
}