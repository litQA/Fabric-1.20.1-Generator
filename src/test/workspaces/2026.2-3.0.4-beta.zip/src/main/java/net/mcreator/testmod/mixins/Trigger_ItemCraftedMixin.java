package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;

@Mixin(ItemStack.class)
abstract class Trigger_ItemCraftedMixin {
	@Inject(method = "onCraftedBy(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;I)V", at = @At("TAIL"), require = 0)
	private void onCraftedBy(Level level, Player player, int amount, CallbackInfo ci) {
		if (player == null || level.isClientSide())
			return;
		System.out.println("[MixinProbe] item_crafted reached");
		net.mcreator.testmod.procedures.Trigger_ItemCraftedProcedure.execute();
	}
}