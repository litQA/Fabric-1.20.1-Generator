package net.mcreator.testmod.procedures;

public class Trigger_EntityStruckByLightningProcedure {
	/* [mixin:entity_struck_by_lightning] */
	public static void execute() {
	}
}