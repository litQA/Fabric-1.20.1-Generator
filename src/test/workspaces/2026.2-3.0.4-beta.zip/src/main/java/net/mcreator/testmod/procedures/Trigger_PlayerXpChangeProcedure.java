package net.mcreator.testmod.procedures;

public class Trigger_PlayerXpChangeProcedure {
	/* [mixin:player_xp_change] */
	public static void execute() {
	}
}