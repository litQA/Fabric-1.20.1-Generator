package net.mcreator.testmod.procedures;

public class Trigger_PlayerCompletesAdvancementProcedure {
	/* [mixin:player_completes_advancement] */
	public static void execute() {
	}
}