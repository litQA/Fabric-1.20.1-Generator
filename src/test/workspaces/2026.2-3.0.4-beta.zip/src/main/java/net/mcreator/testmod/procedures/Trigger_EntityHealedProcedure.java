package net.mcreator.testmod.procedures;

public class Trigger_EntityHealedProcedure {
	/* [mixin:entity_healed] */
	public static void execute() {
	}
}