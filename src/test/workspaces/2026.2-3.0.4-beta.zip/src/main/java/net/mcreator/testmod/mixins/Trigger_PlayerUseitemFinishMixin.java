package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerPlayer;

@Mixin(ItemStack.class)
abstract class Trigger_PlayerUseitemFinishMixin {
	@Inject(method = "finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;", at = @At("HEAD"), cancellable = true, require = 0)
	private void onFinishUsingItem(Level level, LivingEntity entity, CallbackInfoReturnable<ItemStack> cir) {
		if (level.isClientSide())
			return;
		if (entity instanceof ServerPlayer serverPlayer && (serverPlayer.connection == null || serverPlayer.hasDisconnected()))
			return;
		System.out.println("[MixinProbe] player_useitem_finish reached");
		net.mcreator.testmod.procedures.Trigger_PlayerUseitemFinishProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			cir.setReturnValue((ItemStack) (Object) this);
	}
}