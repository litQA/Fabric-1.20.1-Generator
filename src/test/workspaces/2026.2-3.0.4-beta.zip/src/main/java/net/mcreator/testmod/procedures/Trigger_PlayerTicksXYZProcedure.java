package net.mcreator.testmod.procedures;

import net.mcreator.testmod.TestmodMod;

public class Trigger_PlayerTicksXYZProcedure {
	/* [mixin:player_ticks] */
	public static void execute(double x, double y, double z) {
		TestmodMod.LOGGER.info(x + "" + y + z);
	}
}