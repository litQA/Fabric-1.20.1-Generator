package net.mcreator.testmod.procedures;

public class Trigger_BlockMultiplaceProcedure {
	/* [mixin:block_multiplace] */
	public static void execute() {
	}
}