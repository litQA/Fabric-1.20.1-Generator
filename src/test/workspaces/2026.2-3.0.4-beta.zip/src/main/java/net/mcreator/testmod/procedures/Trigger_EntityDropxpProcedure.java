package net.mcreator.testmod.procedures;

public class Trigger_EntityDropxpProcedure {
	/* [mixin:entity_dropxp] */
	public static void execute() {
	}
}