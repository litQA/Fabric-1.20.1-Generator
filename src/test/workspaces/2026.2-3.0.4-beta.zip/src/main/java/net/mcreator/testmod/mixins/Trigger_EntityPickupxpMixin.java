package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.server.level.ServerPlayer;

@Mixin(ExperienceOrb.class)
abstract class Trigger_EntityPickupxpMixin {
	@Inject(method = "playerTouch(Lnet/minecraft/world/entity/player/Player;)V", at = @At("HEAD"), cancellable = true, require = 0)
	private void onPlayerTouch(Player player, CallbackInfo ci) {
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer.takeXpDelay != 0)
			return;
		System.out.println("[MixinProbe] entity_pickupxp reached");
		net.mcreator.testmod.procedures.Trigger_EntityPickupxpProcedure.execute();
		if (net.mcreator.testmod.network.TestmodModUtils.consumeEventCanceled())
			ci.cancel();
	}
}