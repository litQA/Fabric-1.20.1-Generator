package net.mcreator.testmod.procedures;

public class Trigger_PlayerTicksProcedure {
	/* [mixin:player_ticks] */
	public static void execute() {
	}
}