package net.mcreator.testmod.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

@Mixin(Entity.class)
abstract class Trigger_EntityStruckByLightningMixin {
	@Inject(method = "thunderHit(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/LightningBolt;)V", at = @At("HEAD"), require = 0)
	private void onThunderHit(ServerLevel level, LightningBolt lightning, CallbackInfo ci) {
		Entity self = (Entity) (Object) this;
		System.out.println("[MixinProbe] entity_struck_by_lightning reached");
		net.mcreator.testmod.procedures.Trigger_EntityStruckByLightningProcedure.execute();
	}
}